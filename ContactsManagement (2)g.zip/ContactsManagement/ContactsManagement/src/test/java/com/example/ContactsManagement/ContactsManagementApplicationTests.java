package com.example.ContactsManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactsManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
