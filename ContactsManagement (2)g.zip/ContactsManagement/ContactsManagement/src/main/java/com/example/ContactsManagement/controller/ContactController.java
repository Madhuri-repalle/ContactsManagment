package com.example.ContactsManagement.controller;

import com.example.ContactsManagement.service.ContactServiceImplementation;
import com.example.ContactsManagement.model.Contact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/contacts")
public class ContactController {
    @Autowired
    private ContactServiceImplementation contactServiceImplementation;
    @PostMapping("/create")

    public Contact createContact(@RequestBody Contact contact){
        return  contactServiceImplementation.createContact(contact);
    }
    @GetMapping("/{email}")
    public Contact getContactByEmail(@PathVariable String email){
        return contactServiceImplementation.getContactByEmail(email);
    }
    @GetMapping()
    public List<Contact> getAllContacts(){
        return contactServiceImplementation.getAllContacts();
    }
    @PutMapping("/{email}")
    public Contact updateContact(@PathVariable String email,@RequestBody Contact updatedContact){
        return contactServiceImplementation.updateContact(email,updatedContact);
    }
    @DeleteMapping("/{email}")
    public void deleteContact(@PathVariable String email){
        contactServiceImplementation.deleteContact(email);
    }
    @PostMapping("/merge")
    public void mergeContacts(@RequestParam String criteria){
        contactServiceImplementation.mergeContacts(criteria);
    }
}
