package com.example.ContactsManagement.Security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepo userRepository;

    public Optional<User> getUser(String email){
        return userRepository.findByEmail(email);
    }
}

