package com.example.ContactsManagement.repository;

import com.example.ContactsManagement.model.Contact;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ContactRepository extends JpaRepository<Contact,Long> {
    //additional methods to retrive data using email and phone number
    Optional<Contact> findByEmail(String email);
    Optional<Contact>findByPhoneNumber(String phoneNumber);

}
