package com.example.ContactsManagement.authentication;

import com.example.ContactsManagement.Security.UserRegisterRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthenticationController {
    @Autowired
    private AuthenticationService service;
    @PostMapping("/user/register")
    public ResponseEntity<AuthenticationRes> userRegister(@RequestBody UserRegisterRequest request){
        return ResponseEntity.ok(service.userRegister(request));
    }

    @PostMapping("/user/authenticate")
    public ResponseEntity<AuthenticationRes> userAuthenticate(@RequestBody AuthenticationReq request){
        return ResponseEntity.ok(service.userAuthenticate(request));
    }
}

