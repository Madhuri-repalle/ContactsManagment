package com.example.ContactsManagement.service;

import com.example.ContactsManagement.model.Contact;

import java.util.List;

public interface ContactService {
    Contact createContact(Contact contact);
    Contact getContactByEmail(String email);
    List<Contact>getAllContacts();
    void deleteContact(String email);
    void mergeContacts(String criteria);
    Contact updateContact(String email,Contact updatedContact);
}

