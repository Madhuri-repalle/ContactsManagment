package com.example.ContactsManagement.service;

import com.example.ContactsManagement.repository.ContactRepository;
import com.example.ContactsManagement.model.Contact;
import jakarta.validation.ValidationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;



@Service
public class ContactServiceImplementation implements ContactService{
    @Autowired
    private ContactRepository contactRepository;

    //to create the contact
    @Override
    public Contact createContact(Contact contact) {
        validateContact(contact);
        return contactRepository.save(contact);
    }

    //to retrive the contact by using email
    @Override
    public Contact getContactByEmail(String email) {
        return contactRepository.findByEmail(email).orElseThrow(()
                -> new IllegalArgumentException("contact not found with email"+email));
    }

    //to retrive all contacts
    @Override
    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }


    //to delete the contact based on email
    @Override
    public void deleteContact(String email) {
        Contact contact=getContactByEmail(email);
        contactRepository.delete(contact);
    }


    //to update the contact based on email
    @Override
    public Contact updateContact(String email, Contact updatedContact) {
        validateContact(updatedContact);
        Contact existingContact=getContactByEmail(email);
        existingContact.setFirstName(updatedContact.getFirstName());
        existingContact.setLastName(updatedContact.getLastName());
        existingContact.setEmail(updatedContact.getEmail());
        existingContact.setPhoneNumber(updatedContact.getPhoneNumber());
        existingContact.setAddress(updatedContact.getAddress());
        return contactRepository.save(existingContact);
    }
    private void validateContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        if (!isAlphabetic(contact.getFirstName()) || !isAlphabetic(contact.getLastName())) {
            throw new ValidationException("First Name and Last Name must contain only alphabetical characters");
        }

        if (!isValidEmail(contact.getEmail())) {
            throw new IllegalArgumentException("Invalid email format");
        }

        if (!isValidPhoneNumber(contact.getPhoneNumber())) {
            throw new IllegalArgumentException("Invalid phone number format");
        }
    }
    private boolean isAlphabetic(String value){
        if (value == null) {
            return false;
        }

        return value.matches("^[a-zA-Z]+$");
    }
    private boolean isValidEmail(String email){
        if (email == null) {
            return false; // or handle the null case as needed
        }
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }
    private boolean isValidPhoneNumber(String phoneNumber){
        return phoneNumber.matches("^\\d{10}$");
    }

    public void mergeContacts(String criteria) {
        List<Contact> contactsToMerge = new ArrayList<>();

        // Retrieve contacts to merge based on the specified criteria
        if ("email".equalsIgnoreCase(criteria)) {
            // Provide an email parameter to findContactsByEmail method
            contactsToMerge = findContactsByEmail("example@example.com"); // Replace with the actual email
        } else if ("phone".equalsIgnoreCase(criteria)) {
            contactsToMerge = findContactsByPhoneNumber();
        } else {
            throw new IllegalArgumentException("Invalid merge criteria. Supported criteria: 'email' or 'phone'");
        }

        // Check if there are contacts to merge
        if (contactsToMerge.size() >= 1) {
            Contact mergedContact = new Contact();

            // Merge information from all contacts into the merged contact
            for (Contact contact : contactsToMerge) {
                mergeContactInfo(mergedContact, contact);
                contactRepository.delete(contact);
            }

            // Save the merged contact in the repository
            contactRepository.save(mergedContact);
        }
    }

    // Method to merge contact information into a single contact
    private void mergeContactInfo(Contact mergedContact, Contact contact) {
        if (mergedContact.getFirstName() == null) {
            mergedContact.setFirstName(contact.getFirstName());
        }
        if (mergedContact.getLastName() == null) {
            mergedContact.setLastName(contact.getLastName());
        }
        if (mergedContact.getEmail() == null) {
            mergedContact.setEmail(contact.getEmail());
        }
        if (mergedContact.getPhoneNumber() == null) {
            mergedContact.setPhoneNumber(contact.getPhoneNumber());
        }
        if (mergedContact.getAddress() == null) {
            mergedContact.setAddress(contact.getAddress());
        }
    }

    // Method to find contacts by email
    private List<Contact> findContactsByEmail(String email) {
        // Implement logic to fetch contacts by email from the database
        return new ArrayList<>();
    }

    // Method to find contacts by phone number
    private List<Contact> findContactsByPhoneNumber() {
        return new ArrayList<>();
    }

}

