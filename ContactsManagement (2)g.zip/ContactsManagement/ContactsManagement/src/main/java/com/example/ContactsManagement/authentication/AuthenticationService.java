package com.example.ContactsManagement.authentication;


import com.example.ContactsManagement.Configuration.JwtTokenService;
import com.example.ContactsManagement.Security.UserRepo;
import com.example.ContactsManagement.Security.Role;
import com.example.ContactsManagement.Security.User;
import com.example.ContactsManagement.Security.UserRegisterRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AuthenticationService {
    @Autowired
    private UserRepo repo;
    @Autowired
    private JwtTokenService jwtService;
    @Autowired
    private AuthenticationManager authenticationManager;
    public AuthenticationRes userRegister(UserRegisterRequest request){
        User user=new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setRoles(Role.USER);
        user.setPassword(request.getPassword());
        repo.save(user);
        String token=jwtService.generateJwtToken(new HashMap<>(),user);
        AuthenticationRes authenticationRes=new AuthenticationRes();
        authenticationRes.setJwtToken(token);
        return authenticationRes;
    }

    public AuthenticationRes userAuthenticate(AuthenticationReq request){
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                request.getUserName(),request.getPassword()
        ));
        var user=repo.findByEmail(request.getUserName()).orElseThrow();
        String token=jwtService.generateJwtToken(new HashMap<>(),user);
        AuthenticationRes authenticationRes=new AuthenticationRes();
        authenticationRes.setJwtToken(token);
        return authenticationRes;

    }


}

