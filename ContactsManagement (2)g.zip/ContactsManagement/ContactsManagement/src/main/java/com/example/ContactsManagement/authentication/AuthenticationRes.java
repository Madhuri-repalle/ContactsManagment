package com.example.ContactsManagement.authentication;

public class AuthenticationRes {
    private String JwtToken;

    public String getJwtToken() {
        return JwtToken;
    }

    public void setJwtToken(String jwtToken) {
        JwtToken = jwtToken;
    }
}
