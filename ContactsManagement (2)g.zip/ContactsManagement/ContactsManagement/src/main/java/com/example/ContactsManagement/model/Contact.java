package com.example.ContactsManagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Contact {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;


    @NotBlank(message = "firstname should require")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "only alphabets should be given")
    private String firstName;


    @NotBlank(message = "lastname should require")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "only alphabets should be given")
    private String lastName;


    @NotBlank(message = "should require")
    @Email(message = "invalid format")
    private String email;


    @NotBlank(message = "phone number should require")
    @Pattern(regexp = "^\\d{10}$", message = "invalid phone number")
    private String phoneNumber;

    private String address;
}
