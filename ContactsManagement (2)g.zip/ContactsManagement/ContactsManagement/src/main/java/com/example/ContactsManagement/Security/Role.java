package com.example.ContactsManagement.Security;

public enum Role {
    ADMIN,
    USER
}
